<html>
	<head>
	<title>E-banking</title>
	  <!-- Bootstrap CSS -->
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<-- <style>


 .container{
	width: 450px;
	padding: 4% 4% 4%;
	margin : auto;
	box-shadow: 10px 10px 5px #888888;
	background-color: #fff;
	text-align: center;
	position:relative;
	top:50px;
	vertical-align: middle;
	background-color: #cfe82e;
}
form{
	align-content: center;
	padding:10px;
	margin-top: 15px;
}
input
{
	margin :5px;
}

a{
	color:#f00f53;
	text-decoration: none;
	align-content: right;
}

.button{
	width :150px;
	margin :10px;
	padding:5px;
	font-weight: bold;
	text-align: center;
	background-color: #a30003;
	position:relative;
	right:-100px;
	color:white;
}


body{
	background-image: url('a1.jpg');
	background-repeat: no-repeat;
	background-size: cover;
}

    </style> -->
</head>

<body>
  <?php include('navbar.php'); ?>
  <div class="container text-center " style="width: 50%; border: 3px solid black; margin-top: 30px ;">

  <div class="center">
      <h1 style="text-align: center">Welcome to Bank of Spark Foundation<h1>

      <p style="text-align: center ; font-size: 20px">Designed by: ANANYA B<p>

  </div>


 <p>A bank is a financial institution licensed to receive deposits and make loans. Banks may also provide financial services such as wealth management, currency exchange, and safe deposit boxes. There are several different kinds of banks including retail banks, commercial or corporate banks, and investment banks.</p>

</body>

</html>
